//
//  DoraemonLoadAnalyze.h
//  DoraemonLoadAnalyze
//
//  Created by yixiang on 2019/1/2.
//  Copyright © 2019年 yixiang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//在控制台打印load耗时
FOUNDATION_EXPORT void printLoadAnalyzeInfo(void);

extern NSMutableArray<NSDictionary *> *dlaLoadModels;

